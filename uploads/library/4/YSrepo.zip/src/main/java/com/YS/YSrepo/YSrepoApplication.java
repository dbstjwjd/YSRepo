package com.YS.YSrepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YSrepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(YSrepoApplication.class, args);
	}

}
